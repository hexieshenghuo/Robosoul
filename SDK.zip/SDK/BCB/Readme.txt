1 impdef JHCap.def JHCap2.dll

2 remove the @1 on every line of def file

3 implib JHCap2.lib JHCap.def