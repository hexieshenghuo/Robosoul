Imports System.Collections.Generic
Imports System.Linq
Imports System.Text
Imports System.Runtime.InteropServices

Public Class JHCap
	Public Const API_OK As Integer = 0
	Public Const API_ERROR As Integer = 1

	Public Const CAMERA_IMAGE_RAW8 As Integer = &H1
	Public Const CAMERA_IMAGE_GRAY8 As Integer = &H2
	Public Const CAMERA_IMAGE_RGB24 As Integer = &H4
	Public Const CAMERA_IMAGE_BGR As Integer = &H100
	Public Const CAMERA_IMAGE_QUAD As Integer = &H200
	Public Const CAMERA_IMAGE_SYNC As Integer = &H10000
	Public Const CAMERA_IMAGE_TRIG As Integer = &H20000
	Public Const CAMERA_IMAGE_STRETCH As Integer = &H1000000

	Public Const CAMERA_IMAGE_BMP As Integer = (CAMERA_IMAGE_RGB24 Or CAMERA_IMAGE_BGR)

	Public Const CAMERA_IN As Integer = &H2
	Public Const CAMERA_OUT As Integer = &H80

	Public Const CAMERA_SNAP_CONTINUATION As Integer = 1
	Public Const CAMERA_SNAP_TRIGGER As Integer = 2

	Public Const CAMERA_RESOLUTION_CROPPING As Integer = 0
	Public Const CAMERA_RESOLUTION_SKIPPING As Integer = 1
	Public Const CAMERA_RESOLUTION_BINNING As Integer = 2

	Public Delegate Function SnapThreadCallback(pImageBuffer As IntPtr, width As Integer, height As Integer, format As Integer) As Integer
	'回调函数申明
	'''///////////////////////////////////////////////////////////////////////////
	'''/////////////////////  初始化 ////////////////////////////////////////////
	'''////////////////////////////////////////////////////////////////////////////
	'获取API版本
	<DllImport("JHCap2.DLL", EntryPoint := "CameraGetVersion", SetLastError := True, CharSet := CharSet.Unicode, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraGetVersion(ByRef major As Integer, ByRef minor As Integer) As Integer
	End Function

	'获取固件版本
	<DllImport("JHCap2.DLL", EntryPoint := "CameraGetFirmVersion", SetLastError := True, CharSet := CharSet.Unicode, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraGetFirmVersion(index As Integer,ByRef ver As Integer) As Integer
	End Function
	
	'获取相机数目
	<DllImport("JHCap2.DLL", EntryPoint := "CameraGetCount", SetLastError := True, CharSet := CharSet.Unicode, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraGetCount(ByRef count As Integer) As Integer
	End Function

	'相机名字
	<DllImport("JHCap2.DLL", EntryPoint := "CameraGetName", SetLastError := True, CharSet := CharSet.Ansi, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraGetName(index As Integer, name As StringBuilder, model As StringBuilder) As Integer
	End Function

	'相机型号
	<DllImport("JHCap2.DLL", EntryPoint := "CameraGetID", SetLastError := True, CharSet := CharSet.Ansi, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraGetID(index As Integer, ByRef modelID As Integer, ByRef productID As Integer) As Integer
	End Function

    '获取最后一个错误的标号
	<DllImport("JHCap2.DLL", EntryPoint := "CameraGetLastError", SetLastError := True, CharSet := CharSet.Ansi, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraGetLastError(ByRef lastError As Integer) As Integer
	End Function
	
	'初始化相机
	<DllImport("JHCap2.DLL", EntryPoint := "CameraInit", SetLastError := True, CharSet := CharSet.Unicode, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraInit(index As Integer) As Integer
	End Function

	'播放（有回调函数）
	<DllImport("JHCap2.DLL", EntryPoint := "CameraPlay", SetLastError := True, CharSet := CharSet.Unicode, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraPlay(m_index As Integer, p As IntPtr, callback As SnapThreadCallback) As Integer
	End Function

	'播放(无回调函数)
	<DllImport("JHCap2.DLL", EntryPoint := "CameraPlayWithoutCallback", SetLastError := True, CharSet := CharSet.Unicode, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraPlayWithoutCallback(m_index As Integer, p As IntPtr) As Integer
	End Function


	'暂停
	<DllImport("JHCap2.DLL", EntryPoint := "CameraStop", SetLastError := True, CharSet := CharSet.Unicode, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraStop(m_index As Integer) As Integer
	End Function

	'释放相机
	<DllImport("JHCap2.DLL", EntryPoint := "CameraFree", SetLastError := True, CharSet := CharSet.Unicode, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraFree(m_index As Integer) As Integer
    End Function

    '设置单帧图像最大时间
    <DllImport("JHCap2.DLL", EntryPoint:="CameraSetTimeout", SetLastError:=True, CharSet:=CharSet.Unicode, ExactSpelling:=False, CallingConvention:=CallingConvention.StdCall)> _
    Public Shared Function CameraSetTimeout(m_index As Integer, timeout As Integer) As Integer
    End Function

    '获取单帧图像最大时间
    <DllImport("JHCap2.DLL", EntryPoint:="CameraGetTimeout", SetLastError:=True, CharSet:=CharSet.Unicode, ExactSpelling:=False, CallingConvention:=CallingConvention.StdCall)> _
    Public Shared Function CameraGetTimeout(m_index As Integer, ByRef timeout As Integer) As Integer
    End Function

	'低分辨率预览高分辨率拍照(index为捕获分辨率序号)
	<DllImport("JHCap2.DLL", EntryPoint := "CameraCaptureImage", SetLastError := True, CharSet := CharSet.Unicode, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraCaptureImage(device_id As Integer, index As Integer, imgbuf As IntPtr, ByRef length As Integer, [option] As Integer) As Integer
	End Function

	'''///////////////////////////////////////////////////////////////////////////
	'''/////////////////////  分辨率 ////////////////////////////////////////////
	'''////////////////////////////////////////////////////////////////////////////

	'设置分辨率
	<DllImport("JHCap2.DLL", EntryPoint := "CameraSetResolution", SetLastError := True, CharSet := CharSet.Unicode, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraSetResolution(m_index As Integer, index As Integer, ByRef width As Integer, ByRef height As Integer) As Integer
	End Function

	'获取分辨率模式
	<DllImport("JHCap2.DLL", EntryPoint := "CameraSetResolutionMode", SetLastError := True, CharSet := CharSet.Unicode, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraSetResolutionMode(m_index As Integer, mode As Integer) As Integer
	End Function

	'设置分辨率模式
	<DllImport("JHCap2.DLL", EntryPoint := "CameraGetResolutionMode", SetLastError := True, CharSet := CharSet.Unicode, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraGetResolutionMode(m_index As Integer, ByRef mode As Integer) As Integer
	End Function

	'获取分辨率总数
	<DllImport("JHCap2.DLL", EntryPoint := "CameraGetResolutionCount", SetLastError := True, CharSet := CharSet.Unicode, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraGetResolutionCount(m_index As Integer, ByRef count As Integer) As Integer
	End Function

	'获取最大分辨率
	<DllImport("JHCap2.DLL", EntryPoint := "CameraGetResolutionMax", SetLastError := True, CharSet := CharSet.Unicode, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraGetResolutionMax(m_index As Integer, ByRef width As Integer, ByRef height As Integer) As Integer
	End Function

	'获取分辨率
	<DllImport("JHCap2.DLL", EntryPoint := "CameraGetResolution", SetLastError := True, CharSet := CharSet.Unicode, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraGetResolution(m_index As Integer, index As Integer, ByRef width As Integer, ByRef height As Integer) As Integer
	End Function

	'设置获取图像格式
	<DllImport("JHCap2.DLL", EntryPoint := "CameraSetOption", SetLastError := True, CharSet := CharSet.Unicode, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraSetOption(m_index As Integer, Format As Integer) As Integer
	End Function

	'获取获取图像格式
	<DllImport("JHCap2.DLL", EntryPoint := "CameraGetOption", SetLastError := True, CharSet := CharSet.Unicode, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraGetOption(m_index As Integer, ByRef Format As Integer) As Integer
	End Function
	'''///////////////////////////////////////////////////////////////////////////
	'''///////////////////// 相机参数 ////////////////////////////////////////////
	'''////////////////////////////////////////////////////////////////////////////

	'获取增益
	<DllImport("JHCap2.DLL", EntryPoint := "CameraGetGain", SetLastError := True, CharSet := CharSet.Unicode, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraGetGain(m_index As Integer, ByRef gain As Integer) As Integer
	End Function

	'设置增益
	<DllImport("JHCap2.DLL", EntryPoint := "CameraSetGain", SetLastError := True, CharSet := CharSet.Unicode, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraSetGain(m_index As Integer, gain As Integer) As Integer
	End Function

	'获取曝光值
	<DllImport("JHCap2.DLL", EntryPoint := "CameraGetExposure", SetLastError := True, CharSet := CharSet.Unicode, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraGetExposure(m_index As Integer, ByRef exposure As Integer) As Integer
	End Function

	'设置曝光值
	<DllImport("JHCap2.DLL", EntryPoint := "CameraSetExposure", SetLastError := True, CharSet := CharSet.Unicode, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraSetExposure(m_index As Integer, exposure As Integer) As Integer
	End Function

	'获取伽马值
	<DllImport("JHCap2.DLL", EntryPoint := "CameraGetGamma", SetLastError := True, CharSet := CharSet.Unicode, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraGetGamma(m_index As Integer, ByRef gamma As Double) As Integer
	End Function

	'设置伽马值
	<DllImport("JHCap2.DLL", EntryPoint := "CameraSetGamma", SetLastError := True, CharSet := CharSet.Unicode, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraSetGamma(m_index As Integer, gamma As Double) As Integer
	End Function

	'获取对比度
	<DllImport("JHCap2.DLL", EntryPoint := "CameraGetContrast", SetLastError := True, CharSet := CharSet.Unicode, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraGetContrast(m_index As Integer, ByRef contrast As Double) As Integer
	End Function

	'设置对比度
	<DllImport("JHCap2.DLL", EntryPoint := "CameraSetContrast", SetLastError := True, CharSet := CharSet.Unicode, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraSetContrast(m_index As Integer, contrast As Double) As Integer
	End Function

	'获取饱和度
	<DllImport("JHCap2.DLL", EntryPoint := "CameraGetSaturation", SetLastError := True, CharSet := CharSet.Unicode, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraGetSaturation(m_index As Integer, ByRef contrast As Double) As Integer
	End Function

	'设置饱和度
	<DllImport("JHCap2.DLL", EntryPoint := "CameraSetSaturation", SetLastError := True, CharSet := CharSet.Unicode, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraSetSaturation(m_index As Integer, contrast As Double) As Integer
	End Function


	'设置黑电平
	<DllImport("JHCap2.DLL", EntryPoint := "CameraSetBlackLevel", SetLastError := True, CharSet := CharSet.Unicode, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraSetBlackLevel(m_index As Integer, blacklevel As Integer) As Integer
	End Function

	'获取黑电平
	<DllImport("JHCap2.DLL", EntryPoint := "CameraGetBlackLevel", SetLastError := True, CharSet := CharSet.Unicode, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraGetBlackLevel(m_index As Integer, ByRef blacklevel As Integer) As Integer
	End Function

	'设置自动曝光值
	<DllImport("JHCap2.DLL", EntryPoint := "CameraSetAEC", SetLastError := True, CharSet := CharSet.Unicode, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraSetAEC(m_index As Integer, aec As Boolean) As Integer
	End Function

	'获取自动曝光值
	<DllImport("JHCap2.DLL", EntryPoint := "CameraGetAEC", SetLastError := True, CharSet := CharSet.Unicode, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraGetAEC(m_index As Integer, ByRef aec As Boolean) As Integer
	End Function

	'设置自动增益
	<DllImport("JHCap2.DLL", EntryPoint := "CameraSetAGC", SetLastError := True, CharSet := CharSet.Unicode, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraSetAGC(m_index As Integer, agc As Boolean) As Integer
	End Function

	'获取自动增益
	<DllImport("JHCap2.DLL", EntryPoint := "CameraGetAGC", SetLastError := True, CharSet := CharSet.Unicode, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraGetAGC(m_index As Integer, ByRef agc As Boolean) As Integer
	End Function

	'设置自动白平衡
	<DllImport("JHCap2.DLL", EntryPoint := "CameraSetAWB", SetLastError := True, CharSet := CharSet.Unicode, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraSetAWB(m_index As Integer, awb As Boolean) As Integer
	End Function

	'获取自动白平衡
	<DllImport("JHCap2.DLL", EntryPoint := "CameraGetAWB", SetLastError := True, CharSet := CharSet.Unicode, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraGetAWB(m_index As Integer, ByRef awb As Boolean) As Integer
	End Function

	'设置图像增强
	<DllImport("JHCap2.DLL", EntryPoint := "CameraSetEnhancement", SetLastError := True, CharSet := CharSet.Unicode, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraSetEnhancement(m_index As Integer, enhance As Boolean) As Integer
	End Function

	'获取图像增强
	<DllImport("JHCap2.DLL", EntryPoint := "CameraGetEnhancement", SetLastError := True, CharSet := CharSet.Unicode, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraGetEnhancement(m_index As Integer, ByRef enhance As Boolean) As Integer
	End Function

	'设置插值算法种类
	<DllImport("JHCap2.DLL", EntryPoint := "CameraSetInterpolation", SetLastError := True, CharSet := CharSet.Unicode, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraSetInterpolation(m_index As Integer, interpolation As Integer) As Integer
	End Function

	'获取插值算法种类
	<DllImport("JHCap2.DLL", EntryPoint := "CameraGetInterpolation", SetLastError := True, CharSet := CharSet.Unicode, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraGetInterpolation(m_index As Integer, ByRef interpolation As Integer) As Integer
	End Function
	
	'设置自动曝光目标值
	<DllImport("JHCap2.DLL", EntryPoint := "CameraSetAETarget", SetLastError := True, CharSet := CharSet.Unicode, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraSetAETarget(m_index As Integer, target As Integer) As Integer
	End Function

	'获取自动曝光目标值
	<DllImport("JHCap2.DLL", EntryPoint := "CameraGetAETarget", SetLastError := True, CharSet := CharSet.Unicode, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraGetAETarget(m_index As Integer, ByRef target As Integer) As Integer
	End Function

	'设置延迟
	<DllImport("JHCap2.DLL", EntryPoint := "CameraSetDelay", SetLastError := True, CharSet := CharSet.Unicode, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraSetDelay(m_index As Integer, delay As Integer) As Integer
	End Function

	'获取延迟
	<DllImport("JHCap2.DLL", EntryPoint := "CameraGetDelay", SetLastError := True, CharSet := CharSet.Unicode, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraGetDelay(m_index As Integer, ByRef delay As Integer) As Integer
	End Function

	'获取水平镜像
	<DllImport("JHCap2.DLL", EntryPoint := "CameraGetMirrorX", SetLastError := True, CharSet := CharSet.Unicode, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraGetMirrorX(m_index As Integer, ByRef flag As Boolean) As Integer
	End Function

	'获取垂直镜像
	<DllImport("JHCap2.DLL", EntryPoint := "CameraGetMirrorY", SetLastError := True, CharSet := CharSet.Unicode, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraGetMirrorY(m_index As Integer, ByRef flag As Boolean) As Integer
	End Function

	'设置水平镜像
	<DllImport("JHCap2.DLL", EntryPoint := "CameraSetMirrorX", SetLastError := True, CharSet := CharSet.Unicode, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraSetMirrorX(m_index As Integer, flag As Boolean) As Integer
	End Function

	'设置垂直镜像
	<DllImport("JHCap2.DLL", EntryPoint := "CameraSetMirrorY", SetLastError := True, CharSet := CharSet.Unicode, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraSetMirrorY(m_index As Integer, flag As Boolean) As Integer
	End Function
	
	'设置图片翻转角度
	<DllImport("JHCap2.DLL", EntryPoint := "CameraSetRotate", SetLastError := True, CharSet := CharSet.Unicode, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraSetRotate(m_index As Integer, rotate As Integer) As Integer
	End Function

	'感兴趣区域
	<DllImport("JHCap2.DLL", EntryPoint := "CameraSetROI", SetLastError := True, CharSet := CharSet.Unicode, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraSetROI(m_index As Integer, offset_width As Integer, offset_height As Integer, width As Integer, height As Integer) As Integer
	End Function

	'设置白平衡增益
	<DllImport("JHCap2.DLL", EntryPoint := "CameraSetWBGain", SetLastError := True, CharSet := CharSet.Unicode, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraSetWBGain(m_index As Integer, rg As Double, gg As Double, bg As Double) As Integer
	End Function

	'获取白平衡增益
	<DllImport("JHCap2.DLL", EntryPoint := "CameraGetWBGain", SetLastError := True, CharSet := CharSet.Unicode, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraGetWBGain(m_index As Integer, ByRef rg As Double, ByRef gg As Double, ByRef bg As Double) As Integer
	End Function

	'图像大小
	<DllImport("JHCap2.DLL", EntryPoint := "CameraGetImageSize", SetLastError := True, CharSet := CharSet.Unicode, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraGetImageSize(m_index As Integer, ByRef width As Integer, ByRef height As Integer) As Integer
	End Function

	'一键白平衡
	<DllImport("JHCap2.DLL", EntryPoint := "CameraOnePushWB", SetLastError := True, CharSet := CharSet.Unicode, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraOnePushWB(m_index As Integer) As Integer
	End Function

	'设置频闪值  
	<DllImport("JHCap2.DLL", EntryPoint := "CameraSetAntiFlicker", SetLastError := True, CharSet := CharSet.Ansi, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraSetAntiFlicker(m_index As Integer, flicker As Integer) As Integer
	End Function
	'flicker==1/50HZ  flicker==2/60HZ
	'获取频闪值
	<DllImport("JHCap2.DLL", EntryPoint := "CameraGetAntiFlicker", SetLastError := True, CharSet := CharSet.Ansi, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraGetAntiFlicker(m_index As Integer, ByRef flicker As Integer) As Integer
	End Function

	'设置高速
	<DllImport("JHCap2.DLL", EntryPoint := "CameraSetHighspeed", SetLastError := True, CharSet := CharSet.Unicode, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraSetHighspeed(m_index As Integer, high As Boolean) As Integer
	End Function

	'获取高速
	<DllImport("JHCap2.DLL", EntryPoint := "CameraGetHighspeed", SetLastError := True, CharSet := CharSet.Unicode, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraGetHighspeed(m_index As Integer, ByRef high As Boolean) As Integer
	End Function

	'载入参数
	<DllImport("JHCap2.DLL", EntryPoint := "CameraLoadParameter", SetLastError := True, CharSet := CharSet.Unicode, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraLoadParameter(m_index As Integer, group As Integer) As Integer
	End Function

	'保存参数
	<DllImport("JHCap2.DLL", EntryPoint := "CameraSaveParameter", SetLastError := True, CharSet := CharSet.Unicode, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraSaveParameter(m_index As Integer, group As Integer) As Integer
	End Function

	'读取GUID
	<DllImport("JHCap2.dll", EntryPoint := "CameraReadSerialNumber")> _
	Public Shared Function CameraReadSerialNumber(device_id As Integer, id As StringBuilder, length As Integer) As Integer
	End Function

	'写入用户数据
	<DllImport("JHCap2.dll", EntryPoint := "CameraWriteUserData")> _
	Public Shared Function CameraWriteUserData(device_id As Integer, data As [String], length As Integer) As Integer
	End Function

	'读取用户数据
	<DllImport("JHCap2.dll", EntryPoint := "CameraReadUserData")> _
	Public Shared Function CameraReadUserData(device_id As Integer, data As StringBuilder, length As Integer) As Integer
	End Function
	'''///////////////////////////////////////////////////////////////////////////
	'''///////////////////// 外触发设置  ////////////////////////////////////////////
	'''////////////////////////////////////////////////////////////////////////////	
	'开启闪光输出
	<DllImport("JHCap2.DLL", EntryPoint := "CameraEnableStrobe", SetLastError := True, CharSet := CharSet.Unicode, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraEnableStrobe(m_index As Integer, en As Boolean) As Integer
	End Function

	'设置闪光电平
	<DllImport("JHCap2.DLL", EntryPoint := "CameraSetStrobePolarity", SetLastError := True, CharSet := CharSet.Unicode, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraSetStrobePolarity(m_index As Integer, high As Boolean) As Integer
	End Function

	'设置图像获取模式 CAMERA_SNAP_CONTINUATION 或者CAMERA_SNAP_TRIGGER
	<DllImport("JHCap2.DLL", EntryPoint := "CameraSetSnapMode", SetLastError := True, CharSet := CharSet.Unicode, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraSetSnapMode(m_index As Integer, snap_mode As Integer) As Integer
	End Function

	'获取图像获取模式
	<DllImport("JHCap2.DLL", EntryPoint := "CameraGetSnapMode", SetLastError := True, CharSet := CharSet.Unicode, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraGetSnapMode(m_index As Integer, ByRef snap_mode As Integer) As Integer
	End Function

	'触发拍照
	<DllImport("JHCap2.DLL", EntryPoint := "CameraTriggerShot", SetLastError := True, CharSet := CharSet.Unicode, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraTriggerShot(m_index As Integer) As Integer
	End Function

	'获取GPI
	<DllImport("JHCap2.DLL", EntryPoint := "CameraGetGPIO", SetLastError := True, CharSet := CharSet.Unicode, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraGetGPIO(m_index As Integer, ByRef val As Integer) As Integer
	End Function

	'设置GPO
	<DllImport("JHCap2.DLL", EntryPoint := "CameraSetGPIO", SetLastError := True, CharSet := CharSet.Unicode, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraSetGPIO(m_index As Integer, mask As Integer, val As Integer) As Integer
	End Function

	'''///////////////////////////////////////////////////////////////////////////
	'''///////////////////// 采集图像  ////////////////////////////////////////////
	'''////////////////////////////////////////////////////////////////////////////	
	'获取图像保存为对应格式文件
    <DllImport("JHCap2.DLL", EntryPoint:="CameraSaveImage", SetLastError:=True, CharSet:=CharSet.Ansi, ExactSpelling:=False, CallingConvention:=CallingConvention.StdCall)> _
    Public Shared Function CameraSaveImage(ByVal m_index As Integer, ByVal p As String, ByVal flag As Boolean, [option] As Integer) As Integer
    End Function
	
	'获取图像保存为BMP文件
    <DllImport("JHCap2.DLL", EntryPoint:="CameraSaveBMPB", SetLastError:=True, CharSet:=CharSet.Ansi, ExactSpelling:=False, CallingConvention:=CallingConvention.StdCall)> _
    Public Shared Function CameraSaveBMPB(ByVal m_index As Integer, ByVal p As String) As Integer
    End Function

	'获取图像保存为JPG文件
    <DllImport("JHCap2.DLL", EntryPoint:="CameraSaveJpegB", SetLastError:=True, CharSet:=CharSet.Ansi, ExactSpelling:=False, CallingConvention:=CallingConvention.StdCall)> _
    Public Shared Function CameraSaveJpegB(ByVal m_index As Integer, ByVal p As String, ByVal flag As Boolean) As Integer
    End Function

	'获取图像缓存区大小
	<DllImport("JHCap2.DLL", EntryPoint := "CameraGetImageBufferSize", SetLastError := True, CharSet := CharSet.Ansi, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraGetImageBufferSize(m_index As Integer, ByRef size As Integer, [option] As Integer) As Integer
    End Function

    '获取ISP图像缓存区大小
    <DllImport("JHCap2.DLL", EntryPoint:="CameraGetISPImageBufferSize", SetLastError:=True, CharSet:=CharSet.Ansi, ExactSpelling:=False, CallingConvention:=CallingConvention.StdCall)> _
    Public Shared Function CameraGetISPImageBufferSize(m_index As Integer, ByRef size As Integer,width As Integer,height As Integer,[option] As Integer) As Integer
    End Function

	'获取图像
	<DllImport("JHCap2.DLL", EntryPoint := "CameraQueryImage", SetLastError := True, CharSet := CharSet.Ansi, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraQueryImage(m_index As Integer, p As IntPtr, ByRef length As Integer, [option] As Integer) As Integer
	End Function
	
	'采集一帧图像显示到指定窗口
	<DllImport("JHCap2.DLL", EntryPoint := "CameraShowImage", SetLastError := True, CharSet := CharSet.Ansi, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraShowImage(m_index As Integer,hWnd As IntPtr, ByRef x As Integer, ByRef y As Integer, ByRef cx As Integer, ByRef cy As Integer, ByRef proc As Integer) As Integer
	End Function

	'''///////////////////////////////////////////////////////////////////////////
	'''///////////////////// 辅助函数  ////////////////////////////////////////////
	'''////////////////////////////////////////////////////////////////////////////
	'BMP文件(buffer RGB 24bit)
	<DllImport("JHCap2.DLL", EntryPoint := "CameraSaveBMP", SetLastError := True, CharSet := CharSet.Ansi, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraSaveBMP(fileName As String, buf As IntPtr, width As Integer, height As Integer) As Integer
	End Function

	'BMP文件(buffer Gray 8bit)
	<DllImport("JHCap2.DLL", EntryPoint := "CameraSaveBMP8", SetLastError := True, CharSet := CharSet.Ansi, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraSaveBMP8(fileName As String, buf As IntPtr, width As Integer, height As Integer) As Integer
	End Function

	'JPG文件(buffer)
	<DllImport("JHCap2.DLL", EntryPoint := "CameraSaveJpeg", SetLastError := True, CharSet := CharSet.Ansi, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraSaveJpeg(fileName As String, buf As IntPtr, width As Integer, height As Integer, color As Boolean, quality As Integer) As Integer
	End Function
	'buf:RGB buffer, color  TRUE = RGB   FALSE = Grayscale quality 0-100
	'显示buffer图像
	<DllImport("JHCap2.DLL", EntryPoint := "CameraShowBufferImage", SetLastError := True, CharSet := CharSet.Ansi, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraShowBufferImage(hWnd As IntPtr, buf As IntPtr, width As Integer, height As Integer, color As Boolean, showStretchMode As Boolean) As Integer
	End Function
	'color :true/RGB  false/Gray showStretchMode:true/strecth
	
	'保存buffer图像
	<DllImport("JHCap2.DLL", EntryPoint := "CameraSaveBufferImage", SetLastError := True, CharSet := CharSet.Ansi, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Function CameraSaveBufferImage(ByVal p As String, buf As IntPtr, width As Integer, height As Integer, color As Boolean, quality As Integer, [option] As Integer) As Integer
	End Function
	
	'发送消息
	<DllImport("User32.dll", EntryPoint := "SendMessage")> _
	Private Shared Function SendMessage(hWnd As IntPtr, Msg As Integer, wParam As Integer, lParam As Integer) As Integer
	End Function

	'重新连接
	<DllImport("JHCap2.DLL", EntryPoint := "CameraReconnect", SetLastError := True, CharSet := CharSet.Ansi, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Sub CameraReconnect(m_index As Integer)
	End Sub
	
	'相机重置
	<DllImport("JHCap2.DLL", EntryPoint := "CameraReset", SetLastError := True, CharSet := CharSet.Ansi, ExactSpelling := False, CallingConvention := CallingConvention.StdCall)> _
	Public Shared Sub CameraReset(m_index As Integer)
    End Sub

    '把RAW数据转换成RGB数据
    <DllImport("JHCap2.DLL", EntryPoint:="CameraISP", SetLastError:=True, CharSet:=CharSet.Ansi, ExactSpelling:=False, CallingConvention:=CallingConvention.StdCall)> _
    Public Shared Function CameraISP(ByVal m_index As Integer, ByVal buf As IntPtr, ByVal ISPbuf As IntPtr, ByVal width As Integer, ByVal height As Integer, ByVal [option] As Integer) As Integer
    End Function
End Class
